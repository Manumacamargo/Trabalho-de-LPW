document.addEventListener('DOMContentLoaded', () => {

    const formCategoria = document.getElementById('form-categoria');
    const formMusica = document.getElementById('form-musica');

    const listaMusicasEl = document.getElementById('lista-musicas');
    const selectCategoriaMusica = document.getElementById('select-categoria-musica');

    const filtroCategoria = document.getElementById('filtro-categoria');
    const buscaMusica = document.getElementById('busca-musica');

    let musicas = JSON.parse(localStorage.getItem('musicas')) || [];
    let categorias = JSON.parse(localStorage.getItem('categorias')) || [];

    // --- DADOS INICIAIS ---
    const categoriasPadrao = [
        { nome: 'Rock', cor: '#ff5733' },
        { nome: 'Pop', cor: '#33aaff' },
        { nome: 'Hip-Hop/Rap', cor: '#ff33aa' },
        { nome: 'Soul', cor: '#aaff33' },
        { nome: 'Jazz', cor: '#33ffaa' },
        { nome: 'Bossa Nova', cor: '#aa33ff' },
        { nome: 'Sertanejo', cor: '#ffaa33' },
        { nome: 'Música Eletrônica (EDM)', cor: '#33aa33' }
    ];

    const musicasPadrao = [
        { titulo: 'Bohemian Rhapsody', artista: 'Queen', categoria: 'Rock' },
        { titulo: 'Shape of You', artista: 'Ed Sheeran', categoria: 'Pop' },
        { titulo: 'Lose Yourself', artista: 'Eminem', categoria: 'Hip-Hop/Rap' },
        { titulo: 'Respect', artista: 'Aretha Franklin', categoria: 'Soul' },
        { titulo: 'Take Five', artista: 'Dave Brubeck', categoria: 'Jazz' },
        { titulo: 'Levels', artista: 'Avicii', categoria: 'Música Eletrônica (EDM)' },
        { titulo: 'Garota de Ipanema', artista: 'Tom Jobim', categoria: 'Bossa Nova' },
        { titulo: 'Ai Se Eu Te Pego', artista: 'Michel Teló', categoria: 'Sertanejo' }
    ];

    // --- Funções de armazenamento ---
    function salvarMusicas() {
        localStorage.setItem('musicas', JSON.stringify(musicas));
    }

    function salvarCategorias() {
        localStorage.setItem('categorias', JSON.stringify(categorias));
    }

    // --- Inicializa categorias e músicas padrão se não existirem ---
    if (categorias.length === 0) {
        categorias = [...categoriasPadrao];
        salvarCategorias();
    }

    if (musicas.length === 0) {
        musicas = [...musicasPadrao];
        salvarMusicas();
    }

    // --- Renderizar dropdowns ---
    function renderizarDropdownsCategorias() {
        if (selectCategoriaMusica) {
            selectCategoriaMusica.innerHTML = '<option value="" selected disabled>Selecione uma categoria...</option>';
        }
        if (filtroCategoria) {
            filtroCategoria.innerHTML = '<option value="todas">Todas as Categorias</option>';
        }

        categorias.forEach(cat => {
            if (selectCategoriaMusica) {
                const optionForm = document.createElement('option');
                optionForm.value = cat.nome;
                optionForm.textContent = cat.nome;
                selectCategoriaMusica.appendChild(optionForm);
            }
            if (filtroCategoria) {
                const optionFiltro = document.createElement('option');
                optionFiltro.value = cat.nome;
                optionFiltro.textContent = cat.nome;
                filtroCategoria.appendChild(optionFiltro);
            }
        });
    }

    // --- Renderizar lista de músicas ---
    function renderizarMusicas(filtro = 'todas') {
        if (!listaMusicasEl) return;

        listaMusicasEl.innerHTML = '';

        let lista = (filtro === 'todas') ? musicas : musicas.filter(m => m.categoria === filtro);

        if (buscaMusica && buscaMusica.value.trim() !== "") {
            const termo = buscaMusica.value.toLowerCase();
            lista = lista.filter(m =>
                m.titulo.toLowerCase().includes(termo) ||
                (m.artista && m.artista.toLowerCase().includes(termo))
            );
        }

        if (lista.length === 0) {
            listaMusicasEl.innerHTML = '<p class="text-center text-muted">Nenhuma música encontrada.</p>';
            return;
        }

        lista.forEach(musica => {
            const categoriaObj = categorias.find(c => c.nome === musica.categoria);
            const cor = categoriaObj ? categoriaObj.cor : "#ccc";

            const item = document.createElement('div');
            item.className = 'musica-item card shadow-sm mb-3';
            item.style.borderLeft = `5px solid ${cor}`;

            item.innerHTML = `
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="card-title mb-1">${musica.titulo}</h5>
                        <h6 class="card-subtitle text-muted">${musica.artista || "Artista desconhecido"}</h6>
                        <span class="badge" style="background-color: ${cor};">${musica.categoria}</span>
                    </div>
                    <button class="btn btn-sm btn-outline-danger btn-delete">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            `;

            const indexReal = musicas.findIndex(m => m.titulo === musica.titulo && m.artista === musica.artista);

            item.querySelector('.btn-delete').addEventListener('click', () => {
                removerMusica(indexReal);
            });

            listaMusicasEl.appendChild(item);
        });
    }

    // --- Handlers ---
    function handleAddCategoria(e) {
        e.preventDefault();
        const nome = document.getElementById('nome-categoria').value.trim();
        const cor = document.getElementById('cor-categoria').value;
        if (!nome) return;

        categorias.push({ nome, cor });
        salvarCategorias();
        renderizarDropdownsCategorias();
        formCategoria.reset();
    }

    function handleAddMusica(e) {
        e.preventDefault();
        const titulo = document.getElementById('titulo-musica').value.trim();
        const artista = document.getElementById('artista-musica').value.trim();
        const categoria = selectCategoriaMusica.value;
        if (!titulo || !categoria) return;

        musicas.push({ titulo, artista, categoria });
        salvarMusicas();
        renderizarMusicas(filtroCategoria ? filtroCategoria.value : "todas");
        formMusica.reset();
    }

    function removerMusica(index) {
        if (!musicas[index]) return;
        if (confirm(`Remover a música "${musicas[index].titulo}"?`)) {
            musicas.splice(index, 1);
            salvarMusicas();
            renderizarMusicas(filtroCategoria ? filtroCategoria.value : "todas");
        }
    }

    // --- Eventos ---
    if (formCategoria) formCategoria.addEventListener('submit', handleAddCategoria);
    if (formMusica) formMusica.addEventListener('submit', handleAddMusica);
    if (filtroCategoria) filtroCategoria.addEventListener('change', () => renderizarMusicas(filtroCategoria.value));
    if (buscaMusica) buscaMusica.addEventListener('input', () => renderizarMusicas(filtroCategoria.value));

    // --- Inicialização ---
    renderizarDropdownsCategorias();
    renderizarMusicas();
});
